import { createBrowserHistory } from 'history';
// To change location from any place
export default createBrowserHistory();